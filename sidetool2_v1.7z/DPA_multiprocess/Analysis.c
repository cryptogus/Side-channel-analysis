
// Analysis.c
//

#include "Analysis.h"

int POINT_VERIFY(unsigned int *POINTS, unsigned int *TRACE_NUM)
{
	trace_HEADER	in_trace						= { 0, };
	FILE			*fp								= NULL;
	char			FILE_MERGE[_FILE_NAME_SIZE_]	= "";

	// 파형 파일 열기 (읽기 모드)
#if defined(_WIN32) || defined(_WIN64)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%s.sft", _FOLD_, _TRACE_FILE_);
#else
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%s.sft", _FOLD_, _TRACE_FILE_);
#endif
	fopen_s(&fp, FILE_MERGE, "rb");
	if (fp == NULL) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                          Failed To Read Trace                         |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}
	
	// 파형 헤더 읽기 (32 바이트)
	/*
	fseek(fp, 16, SEEK_SET);
	fread(&in_trace.trace_no, sizeof(unsigned int),   1, fp);
	fread(&in_trace.point_no, sizeof(unsigned int),   1, fp);
	in_trace.point_no /= 4;
	*/
/** test */
	fseek(fp, 20, SEEK_SET);
	fread(&in_trace.trace_no, sizeof(unsigned int),   1, fp);
	fread(&in_trace.point_no, sizeof(unsigned int),   1, fp);
	
	fclose(fp);

	printf(" ---------------------------Trace Information---------------------------\n");
	printf("|	The Type Of Point	:	FLOAT				|\n");
	printf("|	The Number Of Trace	:	%d				|\n", in_trace.trace_no);
	printf("|	The Number Of Point	:	%d				|\n", in_trace.point_no);
	printf(" -----------------------------------------------------------------------\n");

	*POINTS = in_trace.point_no;
	*TRACE_NUM = in_trace.trace_no;

	return _PASS_;
}