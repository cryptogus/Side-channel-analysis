/**
 * @file First_Order_CPA.c
 */

#include "Analysis.h"

// AES S-Box
static unsigned char AES_S[256] = {
	0x63, 0x7c, 0x77, 0x7b, 0xf2, 0x6b, 0x6f, 0xc5, 0x30, 0x01, 0x67, 0x2b, 0xfe, 0xd7, 0xab, 0x76,
	0xca, 0x82, 0xc9, 0x7d, 0xfa, 0x59, 0x47, 0xf0, 0xad, 0xd4, 0xa2, 0xaf, 0x9c, 0xa4, 0x72, 0xc0,
	0xb7, 0xfd, 0x93, 0x26, 0x36, 0x3f, 0xf7, 0xcc, 0x34, 0xa5, 0xe5, 0xf1, 0x71, 0xd8, 0x31, 0x15,
	0x04, 0xc7, 0x23, 0xc3, 0x18, 0x96, 0x05, 0x9a, 0x07, 0x12, 0x80, 0xe2, 0xeb, 0x27, 0xb2, 0x75,
	0x09, 0x83, 0x2c, 0x1a, 0x1b, 0x6e, 0x5a, 0xa0, 0x52, 0x3b, 0xd6, 0xb3, 0x29, 0xe3, 0x2f, 0x84,
	0x53, 0xd1, 0x00, 0xed, 0x20, 0xfc, 0xb1, 0x5b, 0x6a, 0xcb, 0xbe, 0x39, 0x4a, 0x4c, 0x58, 0xcf,
	0xd0, 0xef, 0xaa, 0xfb, 0x43, 0x4d, 0x33, 0x85, 0x45, 0xf9, 0x02, 0x7f, 0x50, 0x3c, 0x9f, 0xa8,
	0x51, 0xa3, 0x40, 0x8f, 0x92, 0x9d, 0x38, 0xf5, 0xbc, 0xb6, 0xda, 0x21, 0x10, 0xff, 0xf3, 0xd2,
	0xcd, 0x0c, 0x13, 0xec, 0x5f, 0x97, 0x44, 0x17, 0xc4, 0xa7, 0x7e, 0x3d, 0x64, 0x5d, 0x19, 0x73,
	0x60, 0x81, 0x4f, 0xdc, 0x22, 0x2a, 0x90, 0x88, 0x46, 0xee, 0xb8, 0x14, 0xde, 0x5e, 0x0b, 0xdb,
	0xe0, 0x32, 0x3a, 0x0a, 0x49, 0x06, 0x24, 0x5c, 0xc2, 0xd3, 0xac, 0x62, 0x91, 0x95, 0xe4, 0x79,
	0xe7, 0xc8, 0x37, 0x6d, 0x8d, 0xd5, 0x4e, 0xa9, 0x6c, 0x56, 0xf4, 0xea, 0x65, 0x7a, 0xae, 0x08,
	0xba, 0x78, 0x25, 0x2e, 0x1c, 0xa6, 0xb4, 0xc6, 0xe8, 0xdd, 0x74, 0x1f, 0x4b, 0xbd, 0x8b, 0x8a,
	0x70, 0x3e, 0xb5, 0x66, 0x48, 0x03, 0xf6, 0x0e, 0x61, 0x35, 0x57, 0xb9, 0x86, 0xc1, 0x1d, 0x9e,
	0xe1, 0xf8, 0x98, 0x11, 0x69, 0xd9, 0x8e, 0x94, 0x9b, 0x1e, 0x87, 0xe9, 0xce, 0x55, 0x28, 0xdf,
	0x8c, 0xa1, 0x89, 0x0d, 0xbf, 0xe6, 0x42, 0x68, 0x41, 0x99, 0x2d, 0x0f, 0xb0, 0x54, 0xbb, 0x16
};

unsigned int HW(unsigned long long x) {
	const unsigned long long m1 = 0x5555555555555555;
	const unsigned long long m2 = 0x3333333333333333;
	const unsigned long long m4 = 0x0f0f0f0f0f0f0f0f;
	x -= (x >> 1) & m1;             //put count of each 2 bits into those 2 bits
	x = (x & m2) + ((x >> 2) & m2); //put count of each 4 bits into those 4 bits 
	x = (x + (x >> 4)) & m4;        //put count of each 8 bits into those 8 bits 
	x += x >> 8;  //put count of each 16 bits into their lowest 8 bits
	x += x >> 16;  //put count of each 32 bits into their lowest 8 bits
	x += x >> 32;  //put count of each 64 bits into their lowest 8 bits
	return x & 0x7f;
}

int First_Order_CPA(struct tm *TIME, unsigned int POINTS, unsigned int TRACE_NUM) {
	/************************************************************************************/
	/*                                     변수 선언                                    */
	/************************************************************************************/
	FILE			*fp									= NULL;
	FILE			*fp2								= NULL;
	FILE			*fpp								= NULL;
	FILE			*fpt								= NULL;

	char			FOLD_MERGE[_FILE_NAME_SIZE_]		= "";
	char			FILE_MERGE[_FILE_NAME_SIZE_]		= "";

	unsigned char	*Plaintext							= NULL;

	unsigned int	i									= 0;		// for (_BLOCK_SIZE, _CANDIDATES_)
	unsigned int	B									= 0;		// Byte
	unsigned int	Guess_Key							= 0;
	unsigned int	Key									= 0;
	unsigned int	Key_HW								= 0;
	unsigned int	R_Key								= 0;
	unsigned int	Right_Key							= 0;
	unsigned int	Index								= 0;
	unsigned int	Percent								= 0;
	unsigned int	Check								= 0;

	__int64			*H_S								= NULL;
	__int64			*H_SS								= NULL;
	__int64			tn									= 0;		// for (TN)
	__int64			pi									= 0;		// for (PI)
	__int64			TN									= 0;		// Trace Number
	__int64			PI									= 0;		// Point Interval

	float			F_Temp								= 0.;

	double			*Temp_Points						= NULL;
	double			*MaxPeak							= NULL;
	double			*W_CS								= NULL;
	double			*W_CSS								= NULL;
	double			**W_HS								= NULL;
	double			Correlation							= 0.;
	double			Correlation_L						= 0.;
	double			Correlation_R						= 0.;
	double			Max									= 0.;
	double			Max_Sec								= 0.;
	double			Ratio								= 0.;

	TN = (__int64)_TRACE_NUM_;
	PI = (__int64)_END_POINT_ - (__int64)_START_POINT_ + (__int64)1;

	// 분석할 바이트 위치 계산
	B = _BYTE_ - 1;


	if (TRACE_NUM < TN) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                    분석 파형 수가 적절치 않습니다.                    |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}

	if (_START_POINT_ < 1 || _START_POINT_ > _END_POINT_) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                분석 범위의 시작 지점이 적절치 않습니다.               |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}

	if (_END_POINT_ > POINTS) {
		printf(" -----------------------------------------------------------------------\n");
		printf("|                 분석 범위의 끝 지점이 적절치 않습니다.                |\n");
		printf(" -----------------------------------------------------------------------\n");
		return _FAIL_;
	}


	/************************************************************************************
	 *                                   변수 동적할당                                   *
	 ************************************************************************************/
	// 평문 저장
	Plaintext = (unsigned char *)malloc(_BLOCK_SIZE_ * sizeof(unsigned char));

	// 분석 포인트 저장
	Temp_Points = (double *)malloc((unsigned int)PI * sizeof(double));

	// 중간값 E[X] 저장
	H_S = (__int64 *)malloc(_GUESS_KEY_NUM_ * sizeof(__int64));

	// 중간값 E[X^2] 저장
	H_SS = (__int64 *)malloc(_GUESS_KEY_NUM_ * sizeof(__int64));

	// 파형 측정값 E[Y] 저장
	W_CS = (double *)malloc((unsigned int)PI * sizeof(double));

	// 파형 측정값 E[Y^2] 저장 
	W_CSS = (double *)malloc((unsigned int)PI * sizeof(double));

	// E[XY] 저장
	W_HS = (double **)malloc(_GUESS_KEY_NUM_ * sizeof(double *));
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		W_HS[Guess_Key] = (double *)malloc((unsigned int)PI * sizeof(double));
	}

	// 각 키 후보군 별 MAXPEAK 저장
	MaxPeak = (double *)malloc(_GUESS_KEY_NUM_ * sizeof(double));

	/************************************************************************************/
	/*                               First Order CPA 시작                               */
	/************************************************************************************/

	// 결과 저장할 폴더 생성
#if defined(_WIN32) || defined(_WIN64)
	sprintf_s(FOLD_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\Result_%02dday_%02dh_%02dm_%02ds", _FOLD_, TIME->tm_mday, TIME->tm_hour, TIME->tm_min, TIME->tm_sec);
#else
	sprintf_s(FOLD_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/Result_%02dday_%02dh_%02dm_%02ds", _FOLD_, TIME->tm_mday, TIME->tm_hour, TIME->tm_min, TIME->tm_sec);
#endif
	mkdir(FOLD_MERGE, 0755);

printf("\n부모 PID: %d\n", getppid());

for (; B < _END_BYTE_; B++) {
	
	pid_t pid = fork();  // 자식 프로세스 생성

	if (pid < 0) {  // fork 실패 시
        perror("fork failed");
		fclose(fpp);
        fclose(fpt);
        exit(1);
    } else if (pid == 0) {  // 자식 프로세스
		printf("자식 프로세스 %d: PID=%d 실행 중\n", B + 1, getpid());
        // 자식 프로세스에서 실행할 작업

		/*
		부모 프로세스가 파일을 열고 있는 상태에서 자식 프로세스들이 동일한 파일에 접근하여 작업을 수행하면, 파일 접근 충돌이 발생할 수 있습니다. 이 문제는 멀티프로세스 환경에서 공통된 파일을 동시에 열고 쓰기를 시도할 때 발생하며, 다음과 같은 상황에서 문제가 될 수 있습니다:
		동시 쓰기 충돌: 여러 프로세스가 동시에 파일에 쓰기를 시도하면, 데이터가 서로 덮어쓰이거나 손상될 수 있습니다. 이는 레이스 컨디션(Race Condition)이라고 하며, 결과의 일관성이 보장되지 않습니다.
		파일 포인터의 위치 관리: 파일을 동시에 읽고 쓰는 프로세스들이 파일 포인터의 위치를 공유하지 않기 때문에, 각 프로세스의 파일 포인터가 예상치 못한 위치로 이동할 수 있습니다. 이를 통해 읽기 및 쓰기의 결과가 엉망이 될 수 있습니다.
		파일 잠금 문제: 파일에 대한 접근을 동기화하지 않으면, 파일이 예상치 않게 잠기거나 데이터가 손실될 위험이 있습니다.
		
		해결 방법
		파일 잠금(Locking) 사용:

		파일을 사용할 때 flock() 같은 파일 잠금 메커니즘을 사용하여 하나의 프로세스만 파일에 접근하도록 제어할 수 있습니다.
		잠금을 설정하여 파일을 안전하게 사용하고, 작업이 끝나면 잠금을 해제합니다.
		파일을 프로세스별로 분리:

		각 프로세스가 독립적으로 파일을 생성하고 작업하도록 하여, 프로세스 간의 파일 접근 충돌을 방지합니다.
		각 프로세스가 자신의 결과를 별도의 파일에 기록하고, 부모 프로세스가 이 파일들을 병합합니다.
		IPC(Inter-Process Communication) 활용:

		파일을 공유하는 대신, 파이프, 메시지 큐, 공유 메모리 등을 사용하여 데이터를 주고받아 파일 접근 충돌을 방지할 수 있습니다.
		*/
		// plaintext(or ciphertext) 파일 열기 (읽기 모드)
#if defined(_WIN32) || defined(_WIN64)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%s.txt", _FOLD_, _PLAIN_FILE_);
#else
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%s.txt", _FOLD_, _PLAIN_FILE_);
#endif
	fopen_s(&fpp, FILE_MERGE, "r");
	if (fpp == NULL) {
		perror("Failed To Read Plaintext");
		return _FAIL_;
	}

	// 파형 파일 열기 (읽기 모드)
#if defined(_WIN32) || defined(_WIN64)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%s.sft", _FOLD_, _TRACE_FILE_);
#else
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%s.sft", _FOLD_, _TRACE_FILE_);
#endif
	fopen_s(&fpt, FILE_MERGE, "rb");
	if (fpt == NULL) {
		perror("Failed To Read Trace");
		return _FAIL_;
	}
	// 값 초기화
	for (pi = 0; pi < PI; pi++) {
		W_CS[pi] = 0.0;
		W_CSS[pi] = 0.0;
		for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
			W_HS[Guess_Key][pi] = 0.0;
		}
	}
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		MaxPeak[Guess_Key] = 0;
		H_S[Guess_Key] = 0;
		H_SS[Guess_Key] = 0;
	}

	// printf(" -----------------------------------------------------------------------\n");
	// printf("|                            %02d-Byte Analysis                         |\n", B + 1);
	// printf(" -----------------------------------------------------------------------\n");
	// text seek set,
	_fseeki64(fpp, (__int64)_START_TRACE_ * _TEXT_SIZE_, SEEK_SET);
	for (tn = _START_TRACE_; tn < _END_TRACE_; tn++) {
		// 진행률 표시
		// Percent = (unsigned int)((double)(tn - _START_TRACE_) / (double)(_TRACE_NUM_) * 100);
		// if (Percent % 10 == 0 && Percent != 0 && Percent != 100 && Check != Percent) {
		// 	printf("%d%%\t", Percent);
		// 	if (Percent == 90) {
		// 		printf("\n");
		// 	}
		// 	Check = Percent;
		// }
		
		for (i = 0; i < _BLOCK_SIZE_; i++) {
#if defined(_WIN32) || defined(_WIN64)
			fscanf_s(fpp, "%hhx", &Plaintext[i]);
#else
			fscanf(fpp, "%hhx", &Plaintext[i]);
#endif
		}
		
		// 32(.sft file의 header) + 4(byte size) * 분석 시작할 trace 순서 * point 수
		_fseeki64(fpt, 32 + ((__int64)POINTS * (__int64)tn + (__int64)_START_POINT_ - (__int64)1) * (__int64)4, SEEK_SET);

		//printf("tell: %lx\n", ftell(fpt));
		for (pi = 0; pi < PI; pi++) {
			fread(&F_Temp, sizeof(float), 1, fpt);
			Temp_Points[pi] = (double)F_Temp;
		}

		// E[Y], E[Y^2] 계산
		for (pi = 0; pi < PI; pi++) {
			W_CS[pi] += Temp_Points[pi];
			W_CSS[pi] += Temp_Points[pi] * Temp_Points[pi];
		}
		int GUESS = 0;
		for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
			
#if _TARGET_ == 0
			Key = Plaintext[B];
#elif _TARGET_ == 1 // Target is AES first addroundkey
			Key = AES_S[Plaintext[B] ^ (Guess_Key + _GUESS_KEY_START_)];
#else
			printf(" -----------------------------------------------------------------------\n");
			printf("|                          Failed to Set Target                         |\n");
			printf(" -----------------------------------------------------------------------\n");
			return _FAIL_;
#endif

			// Hamming Weight 계산
			Key_HW = HW(Key);

			// E[X], E[X^2] 계산
			H_S[Guess_Key]  += (__int64)Key_HW;
			H_SS[Guess_Key] += (__int64)(Key_HW * Key_HW);

			// E[XY] 계산
			for (pi = 0; pi < PI; pi++) {
				W_HS[Guess_Key][pi] += (double)Key_HW * Temp_Points[pi];
			}
		}
		
#if _MAX_PEAK_TRACE_
		// Max Peak Trace 저장
		if (!((tn + 1) % _TRACE_UNIT_)) {
			// Max Peak Trace 저장할 파일 열기
#if defined(_WIN32) || defined(_WIN64)
			sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_MAX_PEAK_UNIT_%d.txt", FOLD_MERGE, B + 1, _TRACE_UNIT_);
#else
			sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%d_MAX_PEAK_UNIT_%d.txt", FOLD_MERGE, B + 1, _TRACE_UNIT_);
#endif
			fopen_s(&fp, FILE_MERGE, "a");

			for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
				for (pi = 0; pi < PI; pi++) {
					Correlation_L = (double)(tn + 1) * W_HS[Guess_Key][pi] - W_CS[pi] * (double)H_S[Guess_Key];
					Correlation_R = ((double)(tn + 1) * (double)H_SS[Guess_Key] - (double)H_S[Guess_Key] * (double)H_S[Guess_Key]) * ((double)(tn + 1) * W_CSS[pi] - W_CS[pi] * W_CS[pi]);

					if (Correlation_R <= (double)0) {
						Correlation = (double)0;
					}
					else {
						Correlation = Correlation_L / sqrt(Correlation_R);
						Correlation = fabs(Correlation);
					}

					if (MaxPeak[Guess_Key] < Correlation) {
						MaxPeak[Guess_Key] = Correlation;
					}
				}

				fprintf_s(fp, "%f ", MaxPeak[Guess_Key]);
			}

			fprintf_s(fp, "\n");

			fclose(fp);

			// 값 초기화
			for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
				MaxPeak[Guess_Key] = 0;
			}
		}
#endif
	}

#if _CORRELATION_TRACE_
#if defined(_WIN32) || defined(_WIN64)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d", FOLD_MERGE, B + 1);
#else
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%d", FOLD_MERGE, B + 1);
#endif
	mkdir(FILE_MERGE, 0755); 
#endif // _CORRELATION_TRACE_

	// 키에 대한 상관계수 계산 및 결과 값 저장
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
#if _CORRELATION_TRACE_
#if defined(_WIN32) || defined(_WIN64)
		sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d\\%03d(0x%02X).txt", FOLD_MERGE, B + 1, Guess_Key + _GUESS_KEY_START_, Guess_Key + _GUESS_KEY_START_);
#else
		sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%d/%03d(0x%02X).txt", FOLD_MERGE, B + 1, Guess_Key + _GUESS_KEY_START_, Guess_Key + _GUESS_KEY_START_);
#endif
		fopen_s(&fp, FILE_MERGE, "w");
#endif // _CORRELATION_TRACE_

		for (pi = 0; pi < PI; pi++) {
			Correlation_L = (double)TN * W_HS[Guess_Key][pi] - W_CS[pi] * (double)H_S[Guess_Key];
			Correlation_R = ((double)TN * (double)H_SS[Guess_Key] - (double)H_S[Guess_Key] * (double)H_S[Guess_Key]) * ((double)TN * W_CSS[pi] - W_CS[pi] * W_CS[pi]);

			if (Correlation_R <= (double)0) {
				Correlation = (double)0;
			}
			else {
				Correlation = Correlation_L / sqrt(Correlation_R);
				Correlation = fabs(Correlation);
			}

#if _CORRELATION_TRACE_
			fprintf_s(fp, "%f\n", Correlation);
#endif

			if (MaxPeak[Guess_Key] < Correlation) {
				MaxPeak[Guess_Key] = Correlation;

#if _GUESS_KEY_NUM_ == 1
				// 최종 분석 결과 저장
				Index = (unsigned int)pi;

				sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_Result.txt", FOLD_MERGE, B + 1);
				fopen_s(&fp2, FILE_MERGE, "w");

				fprintf_s(fp2, "Point		: %d\n", Index + _START_POINT_);
				fprintf_s(fp2, "Correlation	: %f", MaxPeak[Guess_Key]);

				fclose(fp2);
#endif
			}
		}

#if _CORRELATION_TRACE_
		fclose(fp);
#endif
	}
#if _GUESS_KEY_NUM_ == 1
	}// pid
} // for (; B < _END_BYTE_; B++) end
#endif // _GUESS_KEY_NUM_ == 1

#if _GUESS_KEY_NUM_ > 1
	// Guess Key Peak 저장
#if defined(_WIN32) || defined(_WIN64)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_GUESS_KEY_PEAK.txt", FOLD_MERGE, B + 1);
#else
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%d_GUESS_KEY_PEAK.txt", FOLD_MERGE, B + 1);
#endif
	fopen_s(&fp, FILE_MERGE, "w");

	// 최종 분석 키 저장
#if defined(_WIN32) || defined(_WIN64)
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s\\%d_RIGHT_KEY.txt", FOLD_MERGE, B + 1);
#else
	sprintf_s(FILE_MERGE, _FILE_NAME_SIZE_ * sizeof(char), "%s/%d_RIGHT_KEY.txt", FOLD_MERGE, B + 1);
#endif
	fopen_s(&fp2, FILE_MERGE, "w");

	Max = 0;
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		fprintf_s(fp, "%f\n", MaxPeak[Guess_Key]);

		if (Max < MaxPeak[Guess_Key]) {
			Max = MaxPeak[Guess_Key];
			R_Key = Guess_Key;
		}
	}

	fclose(fp);

	fprintf_s(fp2, "  1st  0x%02X  %f\n", R_Key, Max);

	MaxPeak[R_Key] = 0.0;

	for (i = 1; i < _CANDIDATES_; i++) {
		for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
			if (Max_Sec < MaxPeak[Guess_Key]) {
				Max_Sec = MaxPeak[Guess_Key];
				Right_Key = Guess_Key;
			}
		}

		if (i == 1) {
			fprintf_s(fp2, "  2nd  0x%02X  %f\n", Right_Key, Max_Sec);
			Ratio = Max / Max_Sec;
		}
		else if (i == 2) {
			fprintf_s(fp2, "  3rd  0x%02X  %f\n", Right_Key, Max_Sec);
		}
		else {
			fprintf_s(fp2, "%3dth  0x%02X  %f\n", i + 1, Right_Key, Max_Sec);
		}

		MaxPeak[Right_Key] = 0.0;
		Max_Sec = 0.0;
		Right_Key = 0;
	}

	fprintf_s(fp2, "\nRatio  %f\n", Ratio);

	fclose(fp2);

	fclose(fpp);
    fclose(fpt);
    exit(0); // 자식 프로세스 종료
	} // pid
} // for (; B < _END_BYTE_; B++) end
#endif
	// 자식 프로세스가 종료될 때까지 부모 프로세스가 대기
	int status;
    while (wait(&status) > 0);

    printf("모든 자식 프로세스가 종료되었습니다.\n");

	/************************************************************************************/
	/*                                  동적 할당 해제                                  */
	/************************************************************************************/
	/*
	자식 프로세스는 부모 프로세스의 메모리를 그대로 복사하여 독립적인 메모리 공간을 가지게 됩니다.
	따라서 부모 프로세스에서 동적 할당한 메모리도 자식 프로세스가 복사해서 사용하지만, 자식 프로세스의 메모리 공간은 부모 프로세스와 완전히 독립적입니다.
	자식 프로세스는 부모의 메모리 상태를 복사하여 시작하지만, 이후의 동작은 서로 독립적입니다. 따라서 자식이 메모리를 수정해도 부모의 메모리에는 영향을 주지 않습니다.
	자식 프로세스가 종료되면, 해당 프로세스에서 사용한 모든 메모리 공간은 운영체제에 의해 자동으로 해제됩니다.
	부모 프로세스와 자식 프로세스는 각각의 동적 할당된 메모리를 독립적으로 관리해야 하며, 자식 프로세스에서 할당된 메모리는 자식에서 해제해야 하고, 부모에서 할당된 메모리는 부모가 관리해야 합니다.
	멀티프로세스 환경에서는 메모리를 공유하지 않으므로, 자식 프로세스와 부모 프로세스 간에 데이터를 주고받으려면 IPC(Inter-Process Communication: 파이프, 메시지 큐, 공유 메모리 등)를 사용해야 합니다.
	*/
	free(Plaintext);
	free(Temp_Points);
	free(H_S);
	free(H_SS);
	free(W_CS);
	free(W_CSS);
	for (Guess_Key = 0; Guess_Key < _GUESS_KEY_NUM_; Guess_Key++) {
		free(W_HS[Guess_Key]);
	}
	free(W_HS);
	free(MaxPeak);

	return _PASS_;
}