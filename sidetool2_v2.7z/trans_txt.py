# 파일 경로 지정
file_path = 'plain.txt'  # 'your_file_path_here'를 실제 파일 경로로 변경하세요.

# 파일 읽기
with open(file_path, 'r') as file:
    content = file.read()

# 각 라인의 문자를 처리하여 한 자리 문자의 앞에 '0'을 추가하는 함수
def add_leading_zero(content):
    modified_content = []
    for line in content.splitlines():
        modified_line = ' '.join([f'0{item}' if len(item) == 1 else item for item in line.split()])
        modified_content.append(modified_line)
    return '\n'.join(modified_content)

# 처리된 내용 얻기
modified_content = add_leading_zero(content)

# 수정된 내용을 새로운 파일에 쓰기
with open('plain2.txt', 'w') as file:
    file.write(modified_content)

print("수정된 내용이 'plain2.txt'에 저장되었습니다.")
