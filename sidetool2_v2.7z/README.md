# 16바이트 한번에 계산 가능한 FOCPA

Ubuntu 22.04LTS
```bash
$ cmake -B build -S . && cd build
$ make -j$(nproc)
```

Windows(use wiht mingw32-make) 
```shell
PS> cmake -G "MinGW Makefiles" -B build -S .
PS> cd build
PS> mingw32-make
PS> del build # 삭제하는데 관리자 권한이 필요하면
```
## 분석 파일에 따라 수정해야할 부분
- `Analysis.c`
`fseek`에서 header 정보 불러오는 부분 -> 파일마다 다를 수 있음.
- `First_Order_CPA.c`
`_fseeki64`, `fscanf` 같은 함수들

DPA reference: https://github.com/nvietsang/dpa-on-aes/tree/master