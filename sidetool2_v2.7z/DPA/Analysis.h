
/**
 * @file Analysis.h
 * @brief Always Check!!!!!
 * @author hhlee 
 * 
 * */ 

#ifndef _ANALYSIS_H_
#define _ANALYSIS_H_


#define _BLOCK_SIZE_ 16
/**
 * 폴더(디렉터리) 경로 
 * 파형 이름
 * 평문 이름
 */
#define       _FOLD_				"../.."
#define _TRACE_FILE_				"AES"
#define _PLAIN_FILE_				"plain2"    // plain과 다른 형식으로 만듦(앞에 %02x로 바꿈)
/**
 * 분석할 파형 수
 */ 
#define _START_TRACE_               0         // default: 0 첫번째 (파형은 0부터, 0 - index)
#define _END_TRACE_                 500         // 최대 파형 갯수 까지(총 500개의 파형이 있다면, 500까지 설정 가능)
#define _TRACE_NUM_					_END_TRACE_ - _START_TRACE_
/**
 * 한번의 Enc(or Dec)시 사용되는 plaintext(or ciphertext) 한줄의 size
 * | ~ | 까지를 한줄로 보았을 때
 * ex) |b6 b6 be b0 7e a7 a7 9f 14 72 bf 8d 1b e3 d3 ae|(0x31) windows에서 작성된거면 개행에 ^M가 붙어서 이렇게 표현함 `vi -v plain.txt`, `xxd -g 1 plain2.txt` 
 * ex) |b6 b6 be b0 7e a7 a7 9f 14 72 bf 8d 1b e3 d3 ae |(0x32)
 * 만약 b6 b6 be b0 7e a7 0 3 14 72 bf 8d 1b e3 d3 ae 과 같이 중간에 0, 3 처럼 1개의 바이트만 사용되는 text 파일이라면 앞에 0을 붙인 text 파일로
 * 수정하여 입력하도록 해야 코드가 동작한다.
 */
#define _TEXT_SIZE_                 0x30
/**
 * bits: Performs a DPA on the bits at the selected location within the byte.
 * 1-byte 기준 0 ~ 7 (0 - index)
 * ex) 해당 값이 0이면, LSB를 기준으로 DPA를 진행한다.
 * ex) 해당 값이 7이면, MSB를 기준으로 DPA를 진행한다.
 */
#define _BITS_					    0

/**
 * 시작 분석 바이트 위치 (1 ~ Block size)
 * 끝마칠 분석 바이트 위치 (1 ~ Block size)
 * ex) _BYTE_ = 1, _END_BYTE_ = 1 이면 첫번째 바이트에 대해서만 분석
 * ex) _BYTE_ = 1, _END_BYTE_ = 16 이면 1 ~ 16 바이트에 대해 분석
 */
#define _BYTE_						2
#define _END_BYTE_					5

/**
 * 분석 시작 포인트
 * 분석 끝 포인트
 */
#define _START_POINT_				1
#define _END_POINT_					7000
/**
 * 분석 시작할 키
 * 분석할 키 수
 */
#define _GUESS_KEY_START_			0
#define _GUESS_KEY_NUM_				256 //1, 256, 65536

/**
 * 출력할 후보 키 수
 */
#define _CANDIDATES_				10

/*----------------------------------------------------------------------------------*/
/*  각 후보 키에 대한 상관계수 분석 결과 출력 (미출력 : 0, 출력 : 1)				*/
/*----------------------------------------------------------------------------------*/
#define _CORRELATION_TRACE_			1

/*----------------------------------------------------------------------------------*/
/*  각 후보 키에 대한 상관계수의 최댓값 출력 (미출력 : 0, 출력 : 1)					*/
/*  Max Peak Trace 출력할 파형 단위 수												*/
/*----------------------------------------------------------------------------------*/
#define _MAX_PEAK_TRACE_			1
#if _MAX_PEAK_TRACE_
#define _TRACE_UNIT_				10
#endif

/************************************************************************************/

typedef struct TRACE_HEADER {
	unsigned int trace_no;
	unsigned int point_no;
} trace_HEADER;
// Using fseeko in linux
//#define __USE_LARGEFILE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
// Using localtime_r in lunux
#include <time.h>

#include <math.h>
// __int64 enabled only in MSVC compiler
#define __int64 int64_t

#if defined(_WIN32) || defined(_WIN64)
    #include <direct.h>
	// _mkdir는 mode를 받지 않기 때문에 이를 처리하기 위한 매크로 정의
    #define mkdir(path, mode) _mkdir(path)
#else
    #include <unistd.h>
    #include <sys/stat.h>
	#include <errno.h>
	#include <stdarg.h>

#define fprintf_s fprintf

// fopen_s 매크로 정의
#define fopen_s(fp, filename, mode) \
    ((fp) == NULL ? EINVAL : ((*(fp) = fopen((filename), (mode))) == NULL ? errno : 0))

// sprintf_s 매크로 정의
#define sprintf_s(buffer, sizeOfBuffer, format, ...) ({ \
    int result = -1; \
    if ((buffer) != NULL && (sizeOfBuffer) > 0 && (format) != NULL) { \
        result = snprintf((buffer), (sizeOfBuffer), (format), __VA_ARGS__); \
        if (result < 0 || result >= (int)(sizeOfBuffer)) { \
            if (result >= (int)(sizeOfBuffer)) { \
                (buffer)[(sizeOfBuffer) - 1] = '\0'; \
            } \
            result = -1; \
        } \
    } \
    result; \
})

#define _fseeki64 fseeko
#endif

#define _FILE_NAME_SIZE_	1000
#define _PASS_				1
#define _FAIL_				0

int POINT_VERIFY(unsigned int *POINTS, unsigned int *TRACE_NUM);
int First_Order_DPA(struct tm *TIME, unsigned int POINTS, unsigned int TRACE_NUM);

#endif 