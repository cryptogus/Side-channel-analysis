def format_hex_from_file(input_filename, output_filename):
    # 파일을 읽어서 각 줄을 리스트로 가져옵니다.
    with open(input_filename, 'r') as file:
        lines = file.readlines()

    # 각 줄의 문자열을 2바이트씩 끊어서 공백을 추가합니다.
    formatted_lines = []
    for line in lines:
        # 개행 문자를 제거하고 2바이트씩 나누어 공백 추가
        formatted_line = ' '.join([line.strip()[i:i+2] for i in range(0, len(line.strip()), 2)])
        formatted_lines.append(formatted_line)

    # 결과를 출력하거나 파일에 저장합니다.
    with open(output_filename, 'w') as file:
        file.write('\n'.join(formatted_lines))

# 예제 파일 이름
input_file = 'demo_output.txt'  # 읽어올 파일 이름
output_file = 'dpa_output.txt'  # 저장할 파일 이름

# 함수 실행
format_hex_from_file(input_file, output_file)
print(f"Formatted output saved to {output_file}")
