import matplotlib.pyplot as plt

# 파일에서 데이터를 읽어옵니다.
file_path = '/home/hhlee/MTR_CPA/Result_02day_14h_57m_47s/5/076(0x4C).txt'  # .txt 파일의 경로를 입력합니다.
#file_path = '/home/hhlee/MTR_CPA/Result_02day_14h_57m_47s/4_GUESS_KEY_PEAK.txt'  # .txt 파일의 경로를 입력합니다.
values = []

# 파일에서 데이터를 읽어 리스트에 저장
with open(file_path, 'r') as file:
    for line in file:
        try:
            values.append(float(line.strip()))  # 각 줄의 값을 float로 변환하여 리스트에 추가
        except ValueError:
            pass  # 만약 변환할 수 없는 값이 있다면 무시하고 지나감

# 데이터를 시각화합니다.
plt.figure(figsize=(12, 6))
plt.plot(values, linestyle='-', color='black')  # 데이터를 선 그래프로 시각화
plt.title('Values from .txt File')
plt.xlabel('Index')
plt.ylabel('Value')
plt.grid(True)
plt.show()
